    clc
    clear
    close all;
    %%defitinion problem 
    model=createmodel();
    costfunction=@(sol1) mycost(sol1,model);
    vars.xhat.min=0;
    vars.xhat.max=1;
    vars.xhat.size=[model.J model.I];
    vars.xhat.count=prod(vars.xhat.size);


    vars.yhat.min=0;
    vars.yhat.max=1;
    vars.yhat.size=[model.K model.J];
    vars.yhat.count=prod(vars.yhat.size);


    Npop=50;



    birey.position=[]; %individual position
    birey.cost = [];  %individual cost 
    birey.sol=[]; %individual solution 
    pop=repmat(birey,Npop,1);

    for i=1:Npop
        pop(i).position=randomsolution(model);
        [pop(i).cost, pop(i).sol]=costfunction(pop(i).position);
    end
cost=[pop.cost];
[cost ,y]=sort(cost);
pop=pop(y);
best.sol=pop(1);


    %%main Loop 
    iteration= 500;
    pc=0.7;
    Npopc=round(pc*Npop/2);
    pm=0.5;
    Npopm=round(pm*Npop);

    for it=1:iteration
        %%crossover
        popc=repmat(birey,round(Npopc),2);
        for k=1:Npopc
            %%selection
            i1=tournamentselection(pop);
            pop1=pop(i1);
            i2=tournamentselection(pop);
            pop2=pop(i2);
            [popc(k,1).position , popc(k,2).position]=crossover(pop1.position,pop2.position);

        [popc(k,1).cost ,popc(k,1).sol]=costfunction(popc(k,1).position);
        [popc(k,2).cost ,popc(k,2).sol]=costfunction(popc(k,2).position);
        end 
        popc=popc(:);
        
        %%mutation
        popm=repmat(birey,Npopm,1);
        for j=1:Npopm
        i1=tournamentselection(pop);
            pop1=pop(i1);
        popm(j).position=mutate(pop1.position,vars);
        [popm(j).cost ,popm(j).sol]=costfunction(popm(j).position);
        end

pop=[pop 
    popc 
    popm];
cost=[pop.cost];
[cost ,y]=sort(cost);
pop=pop(y);


%%delete
pop=pop(1:Npop);
bestsol=pop(1);
bestcost(it)=bestsol.cost;
if bestsol.sol.Isfeasible 
Flag='*';
else
    Flag='';
end

disp(['iteration' num2str(it) ',Best Cost=' num2str(bestcost(it)) Flag]);
    end

    figure;
    semilogy(bestcost);
    xlabel('iteration');
    ylabel('Best solution');