function y=mutate(x,vars)
y.xhat=oldmutate(x.xhat,vars.xhat.min,vars.xhat.max);
y.yhat=oldmutate(x.yhat,vars.yhat.min,vars.yhat.max);

end
function y=oldmutate(x,varmin,varmax)
    n=numel(x);
     mu=0.5;
    y=ceil(n*mu); %ceil is rounding up 
    j=randsample(n,y); 
    sigma=0.1*(varmax-varmin);
    y=x;
    y(j)=x(j)+sigma*randn(size(j)); 

    y(j)=max(y(j),varmin);
    y(j)=min(y(j),varmax);


end