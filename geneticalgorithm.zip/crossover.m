
function [y1 y2]=crossover(x1,x2)
[y1.xhat y2.xhat]=oldcrossover(x1.xhat,x2.xhat);
[y1.yhat y2.yhat]=oldcrossover(x1.yhat,x2.yhat);
end


function [y1 y2]=oldcrossover(x1,x2)
alpha=unifrnd(0,1,size(x1)); %example %20  %80 
y1=alpha.*x1+(1-alpha).*x2;
y2=alpha.*x2+(1-alpha).*x1;

end