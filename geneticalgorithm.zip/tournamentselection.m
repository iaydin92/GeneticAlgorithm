function i=tournamentselection(pop)
n=numel(pop);
s=randsample(n,10);
spop=pop(s);
scost=[spop.cost];
[cost ,y]=min(scost);
i=s(y);
end