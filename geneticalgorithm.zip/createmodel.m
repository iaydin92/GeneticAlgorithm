function model=createmodel()
I=20;%number of customers 
J=5; %number of distributors
K=3; %number of concrete batching plants 
R=[200    310    210    330    440    390    210    500    330    330    180 100    240    260    320    230    350    470    110    490]; %needed concrete m3
D=[1350   1350   1800   1800   1800]; %capacity of distributors 
p=[2800 3000 3500]; % capacity of plants 
a=[41	28	27	16	42	16	24	19	24	37	22	46	24	24	38	30	21	36	15	43
46	16	12	20	48	6	21	22	8	10	13	13	12	37	7	29	7	42	19	10
22	30	21	10	32	38	8	16	16	24	34	44	10	42	32	45	6	5	37	4
10	6	28	40	30	3	48	15	21	43	42	31	25	28	34	18	37	41	46	39
8	22	48	44	45	30	26	2	16	31	48	18	3	21	19	24	41	16	42	12]; %price list between distributors customer
b=  [18    15    12    19   12
    16    11    10    11    18
    18    11    12    10    11]; %price list between plants distributors 


model.I= I;
model.J=J;
model.K=K;
model.R=R;
model.D=D;
model.p=p;
model.a=a;
model.b=b;



end

